package lu.svv.saa.linklaters.privacypolicies.type;

public enum SentenceOperation {
  ADD, AVERAGE
}
